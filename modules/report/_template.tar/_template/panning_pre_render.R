metadata_for_panning <- metadata %>%
    separate_longer_delim(panning_id, "_") %>%
    mutate(panning_id = as.numeric(panning_id))

# read in all of the counts
vroom(fs::dir_ls(
    #path = "/vast/scratch/users/zeglinski.k/pfs230_d13d14/processed_tsv/",
    glob = "*_clone_information.tsv")) %>%
    left_join(metadata_for_panning, by = c("sample_id" = "sample_num"),
              multiple = "all", relationship = "many-to-many")  -> all_counts_filtered

all_nucleotide_files <- fs::dir_ls(
    #path = "/vast/scratch/users/zeglinski.k/pfs230_d13d14/processed_tsv/",
    glob = "*_nucleotide_sequences.tsv")

#### FUNCTIONS ####
calculate_log_fc <- function(wide_form_counts){

    # now we need to pair up the columns
    # get all columns except the CDR3 AA sequence
    all_count_columns <- colnames(wide_form_counts)[3:ncol(wide_form_counts)]

    # all combinations of the columns
    # numerator and denominator refer to their position in the logfc calculation
    expand_grid(numerator = all_count_columns, denominator = all_count_columns) %>%
        # we need to filter out the ones that don't make sense
        # so split the column names into informative columns we can filter on
        mutate(
            numerator_round = as.numeric(
                str_remove(str_extract(numerator, "R[0-9]"), "R")),
            numerator_replicate = as.numeric(
                    str_remove(str_extract(numerator, "Rep[0-9]"), "Rep")),
            denominator_round = as.numeric(
                str_remove(str_extract(denominator, "R[0-9]"), "R")),
            denominator_replicate = as.numeric(
                    str_remove(str_extract(denominator, "Rep[0-9]"), "Rep"))) %>%
        # then filter out the ones that don't make sense
        filter(numerator_round > denominator_round) %>% # numerator round must be greater
        filter(numerator_replicate == denominator_replicate | is.na(numerator_replicate == denominator_replicate)) %>% # same replicate
        select(c(numerator, denominator)) -> combinations

    # now, we need to calculate the log2 fold change for each of these combinations
    for (i in seq_len(nrow(combinations))) {
        this_numerator <- combinations$numerator[i]
        this_denominator <- combinations$denominator[i]
        this_comparison <- paste0(this_numerator, "_vs_", this_denominator)

        # calculate the log2 fold change
        wide_form_counts <- wide_form_counts %>%
            mutate(!!this_comparison :=
                log2((!!sym(this_numerator) + 10) / (!!sym(this_denominator) + 10)))
    }
    return(wide_form_counts)
}

# function to create the count matrix
make_count_matrix <- function(long_form_counts, id){
    # TODO: make this function work when there aren't replicates
    # TODO: make this work with or without full AA sequence
    # filter to the panning id

    long_form_counts %>%
        filter(as.numeric(panning_id) == id) %>%
        select(c(cdr3_aa, cdr3_cpm, round, replicate)) %>%
        mutate(round = paste0("R", round)) %>% # col names can't start with a number
        pivot_wider(names_from = c(round, replicate),
            values_from = cdr3_cpm) %>%
        # replace R0 zeroes with NA
        replace_na(list(R0_NA = 0)) -> wide_form_counts

        # need to re-add the full AA sequence back in (based on count)
        long_form_counts %>%
            filter(as.numeric(panning_id) == id) %>%
            group_by(cdr3_aa) %>%
            summarise(sequence_alignment_aa = sequence_alignment_aa[which.max(cdr3_cpm)]) %>%
            left_join(wide_form_counts, by = "cdr3_aa") -> wide_form_counts_with_full_aa_seq

        # calculate log fold change
        wide_form_counts_with_fc <- calculate_log_fc(wide_form_counts_with_full_aa_seq)

        return(wide_form_counts_with_fc)
}

cluster_from_count_matrix_cdr3 <- function(
    count_matrix, max_round = 2, identity_threshold = 0.8, length_threshold = 0.8) {
    # we are using cd hit to cluster the sequences
    cdhit_result <- CellaRepertorium::cdhit(
        Biostrings::AAStringSet(count_matrix$cluster_lead),
        identity = identity_threshold, # % identity
        min_length = 5, # throws out anything shorter than this
        s = length_threshold, # 90% length tolerance
        G = 1, # global alignment (default)
        g = 1, # slow but accurate mode
        only_index = FALSE)

    # then, for each sequence compute the max final round abundance
    # this will be used to choose the cluster lead
    count_matrix %>%
        select(starts_with(paste0("R", max_round))) %>%
        select(!contains("vs")) %>% # remove logfc
        mutate(max_final_round_abundance =
            purrr:::reduce(select(., everything()), pmax, na.rm = TRUE)) %>%
        pull(max_final_round_abundance) -> max_final_round_abundance

    # then combine the cluster information with the count matrix
    clustered_count_matrix <- cdhit_result %>%
        left_join(count_matrix, by = c("seq" = "cluster_lead")) %>%
        select(!contains("vs")) %>% # remove logfc, will calculate again for the clusters
        mutate(max_final_round_abundance = max_final_round_abundance) %>%
        group_by(cluster_idx) %>%
        summarise(
            cluster_lead = seq[which.max(max_final_round_abundance)],
            cluster_size = n_cluster[1], # cd-hit already calculated this for us
            across(starts_with("R"), \(x) sum(x, na.rm = TRUE)),
            cluster_members = paste(seq, collapse = ",")
            )
    # calculate log fold change with the new counts
    # (since they have been summed for each cluster)
    clustered_count_matrix_with_fc <- clustered_count_matrix %>%
        calculate_log_fc() %>%
        mutate(max_final_round_abundance =
            purrr:::reduce(select(., matches(paste0("R", max_round, "_Rep.$|R", max_round, "_NA$"))), pmax, na.rm = TRUE)) %>%
        mutate(max_logFC =
            purrr:::reduce(select(., matches(paste0("R", max_round, ".*_vs_R0"))), pmax, na.rm = TRUE))

    return(clustered_count_matrix_with_fc)
}

cluster_from_count_matrix_cdr3_init <- function(
    count_matrix, max_round = 2, identity_threshold = 0.9, length_threshold = 0.9) {
    # we are using cd hit to cluster the sequences
    cdhit_result <- CellaRepertorium::cdhit(
        Biostrings::AAStringSet(count_matrix$cdr3_aa),
        identity = identity_threshold, # % identity
        min_length = 5, # throws out anything shorter than this
        s = length_threshold, # 90% length tolerance
        G = 1, # global alignment (default)
        g = 1, # slow but accurate mode
        only_index = FALSE)

    # then, for each sequence compute the max final round abundance
    # this will be used to choose the cluster lead
    count_matrix %>%
        select(starts_with(paste0("R", max_round))) %>%
        select(!contains("vs")) %>% # remove logfc
        mutate(max_final_round_abundance =
            purrr:::reduce(select(., everything()), pmax, na.rm = TRUE)) %>%
        pull(max_final_round_abundance) -> max_final_round_abundance

    # then combine the cluster information with the count matrix
    clustered_count_matrix <- cdhit_result %>%
        left_join(count_matrix, by = c("seq" = "cdr3_aa")) %>%
        select(!contains("vs")) %>% # remove logfc, will calculate again for the clusters
        mutate(max_final_round_abundance = max_final_round_abundance) %>%
        group_by(cluster_idx) %>%
        summarise(
            cluster_lead = seq[which.max(max_final_round_abundance)],
            cluster_size = n_cluster[1], # cd-hit already calculated this for us
            across(starts_with("R"), \(x) sum(x, na.rm = TRUE)),
            cluster_members = paste(seq, collapse = ",")
            )
    # calculate log fold change with the new counts
    # (since they have been summed for each cluster)
    clustered_count_matrix_with_fc <- clustered_count_matrix %>%
        calculate_log_fc() %>%
        mutate(max_final_round_abundance =
            purrr:::reduce(select(., matches(paste0("R", max_round, "_Rep.$|R", max_round, "_NA$"))), pmax, na.rm = TRUE)) %>%
        mutate(max_logFC =
            purrr:::reduce(select(., matches(paste0("R", max_round, ".*_vs_R0"))), pmax, na.rm = TRUE))

    return(clustered_count_matrix_with_fc)
}

plot_cluster_pca <- function(pca_data, table_data, name){
    name <- as.character(name)
    # make the shared data for crosstalk
    pca_data_shared <- SharedData$new(
        pca_data, key = ~cluster_lead, group = name)

    table_data_shared <- SharedData$new(
        table_data, key = ~cluster_lead, group = name)

    # make the pca plot
    pca_plot <- ggplot(
        pca_data_shared, aes(PC1, PC2, text = cluster_lead)) +
        geom_point(
            aes(size = log10(max_final_round_abundance)),
            alpha = 0.3, shape = 21, stroke = 0.25,
            colour = "#760a2a", fill = "#DC7F9B") +
        theme_minimal()

    # warn people if not enough sequences for a top 100
    if (nrow(pca_data) < 100){
        pca_plot <- pca_plot + labs(
            title = paste0("Enriched cluster diversity plot for ", name),
            subtitle = "Note: as there are less than 100 clusters, a top 100 is not reported")
    } else {
        pca_plot <- pca_plot + labs(title = paste0("Enriched cluster diversity plot for ", name))
    }

    pca_plot_interactive <- ggplotly(pca_plot, tooltip = "text") %>%
        layout(showlegend = TRUE) %>%
        highlight(
            on = "plotly_selected",
            opacityDim = 0.55,
            color = "#ff004c",
            persistent = FALSE) %>%
        toWebGL() %>% # makes it faster
        suppressWarnings()

    # make the table
    table_interactive <- datatable(table_data_shared,
        options = list(
            paging = TRUE,    ## paginate the output
            pageLength = 10,  ## number of rows to output for each page
            scrollX = TRUE,   ## enable scrolling on X axis
            autoWidth = TRUE, ## use smart column width handling
            dom = "Bfrtip",
            colReorder = TRUE,
            buttons = c("csv", "excel"),
            columnDefs = list(
                list(targets = "_all", className = "dt-center"),
                list(targets = "cluster_members", visible = FALSE),
                list(targets = "full_nt_sequence", visible = FALSE),
                list(targets = "full_aa_sequence", visible = FALSE),
                list(targets = "trimmed_nt_sequence", visible = FALSE))),
        style = "bootstrap",
        rownames = FALSE,
        extensions = c("Buttons", "ColReorder")
        ) %>%
        formatRound(columns = which(sapply(table_data, is.numeric)), digits = 2)

    # put them together (need suppressWarnings bc of the hacky use of
    # widths to put them on top of one another)

    if (nrow(pca_data) < 100){
        interactive_plot <- suppressWarnings(bscols(
            pca_plot_interactive,
            table_interactive,
            widths = c(12, 12), device = "md"))
    } else {
        interactive_plot <- suppressWarnings(bscols(
            filter_checkbox("diversity_box", "Show top 100 sequences", pca_data_shared, ~top_100),
            pca_plot_interactive,
            table_interactive,
            widths = c(12, 12, 12), device = "md"))
    }

    interactive_plot
}

get_full_sequences <- function(cdr3s, nucleotide_sequences, trim_5p = "", trim_3p = ""){
    # choose most common nucleotide sequence for each CDR3
    nucleotide_sequences %>%
        filter(cdr3_aa %in% cdr3s) %>%
        filter(nchar(sequence_alignment) > 330) %>%
        summarise(
            n = n(),
            cdr3_aa = cdr3_aa[1],
            v_cigar = v_cigar[1],
            j_cigar = j_cigar[1],
            .by = sequence_alignment
        ) %>%
        group_by(cdr3_aa) %>%
        summarise(most_abundant_sequence = sequence_alignment[which.max(n)],
            v_cigar = v_cigar[which.max(n)],
            j_cigar = j_cigar[which.max(n)]) -> nucleotide_sequences_for_each_cdr3

    if(nrow(nucleotide_sequences_for_each_cdr3) != length(cdr3s)){
        message("Not all CDR3s have a nucleotide sequence, retrying without length filter")
        nucleotide_sequences %>%
        filter(cdr3_aa %in% cdr3s) %>%
        #filter(nchar(sequence_alignment) > 330) %>%
        summarise(
            n = n(),
            cdr3_aa = cdr3_aa[1],
            v_cigar = v_cigar[1],
            j_cigar = j_cigar[1],
            .by = sequence_alignment
        ) %>%
        group_by(cdr3_aa) %>%
        summarise(most_abundant_sequence = sequence_alignment[which.max(n)],
            v_cigar = v_cigar[which.max(n)],
            j_cigar = j_cigar[which.max(n)]) -> nucleotide_sequences_for_each_cdr3
    }

    # now, add the missing nucleotides
    # this is copy pasted from the reference file
    ref_5p <- "CAGGTGCAGCTGCAGGAGTCTGGGGGAGGCTTGGTG"
    ref_3p <- "GGGACCCAGGTCACCGTCTCCTCA"

    nucleotide_sequences_for_each_cdr3 %>%
    mutate(
        add_to_5p = (str_extract(
            v_cigar, "[0-9]+(?=N[0-9]+)")), # number in front of first N
        add_to_3p = str_remove(str_extract(
            j_cigar, "[0-9]+N(?!(?s:.*)[0-9]+N)"), "N")) %>% # number in front of last N
    mutate( #idk why but we need to minus 1 from the 3p number
        add_to_5p = as.numeric(add_to_5p),
        add_to_3p = as.numeric(add_to_3p) - 1) %>%
        # get rid of NAs
    replace_na(list(add_to_5p = 0, add_to_3p = 0)) %>% # if nothing missing, don't add
    # need to be careful how we add the bases since we might need to add 0
    # so construct the 3p added bases and 5p added bases separately
    mutate(
        added_bases_5p = case_when(
            add_to_5p == 0 ~ "",
            TRUE ~ str_sub(ref_5p, 1, add_to_5p)
        ), added_bases_3p = case_when(
            add_to_3p == 0 ~ "",
            TRUE ~ str_sub(ref_3p, -add_to_3p, -1)
        )) %>%
    mutate(completed_sequence = str_c(
        added_bases_5p,
        most_abundant_sequence,
        added_bases_3p)) %>%
    # remove gaps
    mutate(completed_sequence = str_remove_all(completed_sequence, "-")) -> completed_nucleotide_sequences

    # trim if necessary
    if (trim_5p != ""){
        completed_nucleotide_sequences$trimmed_sequence <- str_remove(
            completed_nucleotide_sequences$completed_sequence,
            paste0("^", trim_5p))

        if (trim_3p != ""){
        completed_nucleotide_sequences$trimmed_sequence <- str_remove(
            completed_nucleotide_sequences$trimmed_sequence,
            paste0(trim_3p, "$"))
        }
    } else if (trim_3p != ""){
        completed_nucleotide_sequences$trimmed_sequence <- str_remove(
            completed_nucleotide_sequences$completed_sequence,
            paste0(trim_3p, "$"))
    }

    nt_sequence_table <- completed_nucleotide_sequences %>%
        select(cdr3_aa, completed_sequence, trimmed_sequence)

    # translate to amino acids because they want that now
    translated_complete_nt <- Biostrings::translate(
        Biostrings::DNAStringSet(nt_sequence_table$completed_sequence),
        if.fuzzy.codon = "solve")

    nt_sequence_table$translated_complete_sequence <- as.character(translated_complete_nt)


    colnames(nt_sequence_table) <- c("cdr3_aa", "full_nt_sequence", "trimmed_nt_sequence", "full_aa_sequence")

    return(nt_sequence_table)
}

make_cluster_pca_data <- function(clustered_data, id, metadata, max_round = 2){
    # make a matrix
    all_combinations <- expand.grid(clustered_data$cluster_lead, clustered_data$cluster_lead)

    matrix(Biostrings::pairwiseAlignment(
        Biostrings::AAStringSet(all_combinations$Var1),
        Biostrings::AAStringSet(all_combinations$Var2),
            substitutionMatrix = "BLOSUM62", scoreOnly = TRUE,
            gapOpening = -10, gapExtension = -1),
        nrow = length(clustered_data$cluster_lead)) -> all_vs_all_matrix

    # do PCA
    pca_data <- irlba::prcomp_irlba(all_vs_all_matrix, n = 2)$x

    # add information about abundance, cluster members etc
    pca_data %>%
        as_tibble() %>%
        mutate(cluster_lead = clustered_data$cluster_lead) %>%
        left_join(select(clustered_data, -cluster_idx), by = "cluster_lead") -> pca_data

    # calculate top 100 based on diversity
    # apply the logFC > 1.5 cutoff
    clustered_data %>%
        filter(max_logFC > 1.5) -> filtered_clustered_data

    # redo the distance matrix after filtering
    all_combinations_filtered <- expand.grid(
        filtered_clustered_data$cluster_lead,
        filtered_clustered_data$cluster_lead)

    matrix(Biostrings::pairwiseAlignment(
        Biostrings::AAStringSet(all_combinations_filtered$Var1),
        Biostrings::AAStringSet(all_combinations_filtered$Var2),
            substitutionMatrix = "BLOSUM62", scoreOnly = TRUE,
            gapOpening = -10, gapExtension = -1),
        nrow = length(filtered_clustered_data$cluster_lead)) -> all_vs_all_matrix_filtered

    dist_matrix <- distance_matrix(
        distances(scale(all_vs_all_matrix_filtered, center = TRUE, scale = TRUE)))

    # choose top 100s
    # in case we don't have 100 sequences to make a top 100 from
    if (nrow(all_vs_all_matrix_filtered) < 100) {
        top_100_diversity_index <- cutree(hclust(dist_matrix), k = nrow(all_vs_all_matrix_filtered))
        less_than_100 <- TRUE
    } else {
        top_100_diversity_index <- cutree(hclust(dist_matrix), k = 100)
        less_than_100 <- FALSE
    }

    filtered_clustered_data %>%
        mutate(cluster_id = top_100_diversity_index) %>% # add cluster id
        group_by(cluster_id) %>%
        slice_max(max_final_round_abundance, n = 1, with_ties = FALSE) %>%
        pull(cluster_lead) -> top_100_diversity

    # calculate top 100 based on enrichment
    # re-cluster based on CDR3 only, at 80%
    pca_data %>%
        cluster_from_count_matrix_cdr3() %>%
        slice_max(max_logFC, n = 100, with_ties = FALSE) %>%
        pull(cluster_lead) -> top_100_enrichment

    # add columns to indicate whether each cluster is in the top 100
    pca_data %>%
        mutate(
            top_100 = case_when(
                cluster_lead %in% top_100_diversity &
                cluster_lead %in% top_100_enrichment ~ "In both top 100s",
                cluster_lead %in% top_100_enrichment ~ "In enrichment top 100 only",
                cluster_lead %in% top_100_diversity ~ "In diversity top 100 only",
                TRUE ~ "In neither top 100"
            )) -> pca_data_with_top_100

    # get full nucleotide sequences
    table_data <- pca_data_with_top_100 %>%
        select(-c(PC1, PC2))

    # can't read in all, just those from the final round of panning for our sample
    # first find the ones we are looking for (this pan, round 2 only)
    wanted_samples <- metadata %>%
        filter(panning_id == id) %>%
        filter(round == max_round) %>%
        pull(sample_num) %>%
        paste0("_")

    wanted_files <- str_subset(all_nucleotide_files, paste(wanted_samples, collapse = "|"))

    nucleotide_sequences <- vroom(wanted_files)
    full_nt_seqs <- get_full_sequences(
        cdr3s = table_data$cluster_lead,
        nucleotide_sequences,
        trim_5p = 'CAGGTGCAGCTGCAG', trim_3p = 'GGTCACCGTCTCCTCA')

    table_data <- table_data %>%
        left_join(full_nt_seqs, by = c(cluster_lead = "cdr3_aa"))

    return(list(
        pca_data = pca_data_with_top_100,
        table_data = table_data,
        top_100_diversity = top_100_diversity,
        top_100_enrichment = top_100_enrichment))
}

determine_enriched <- function(all_counts_filtered, id, logfc_cutoff = 0, max_round = 2){
    enriched_sequences <- make_count_matrix(
        all_counts_filtered, id = id) %>%
    filter(if_any(matches(paste0("R", max_round, ".*_vs_R0.*")), ~. > 0)) %>%
    filter(nchar(sequence_alignment_aa) > 110) %>%
    filter(nchar(cdr3_aa) > 5) %>% # remove short sequences, or cd hit will crash
    cluster_from_count_matrix_cdr3_init(max_round = max_round) %>%
    filter(if_any(matches(paste0("R", max_round, "_Rep.*")), ~. > 10)) %>%
    filter(max_logFC > logfc_cutoff)
    if(nrow(enriched_sequences) == 0){
        stop("Error: no enriched sequences found")
    }
    return(enriched_sequences)
}

make_interactive_tree_data <- function (starting_data, which_round, id, enriched = FALSE) {
  if (nrow(starting_data) == 0) {
    stop("Error: no nanobody sequences found!")
  }
  # get the top 100 (abundant or enriched) from starting data
  if (enriched) {
    # sort by the logFC column (we only do this for final round)
    starting_data <- starting_data %>%
      arrange(desc(max_logFC)) %>%
      slice_head(n = 100)
  } else {
    # if not enriched, we are working with the all_counts_filtered table
    starting_data <- starting_data %>%
    filter(panning_id == id) %>%
    filter(round == which_round) %>%
    arrange(desc(cdr3_cpm)) %>%
    slice_head(n = 100)
  }

  # make an AAStringSet of our CDR3s
  if (enriched) {
    top_100_cdr3 <- Biostrings::AAStringSet(starting_data$cluster_lead)
    names(top_100_cdr3) <- starting_data$cluster_lead
  } else {
    top_100_cdr3 <- Biostrings::AAStringSet(starting_data$cdr3_aa)
    names(top_100_cdr3) <- starting_data$cdr3_aa
  }

  # do MSA, make distance matrix and then make phylogenetic tree
  alignment <- msa::msa(top_100_cdr3, method = "ClustalOmega", type = "protein")
  alignment_matrix <- seqinr::dist.alignment(
    msa::msaConvert(alignment, type = "seqinr::alignment"), matrix = "identity")
  clustered <- ape::njs(alignment_matrix)

  # layout the tree with ggtree package (daylight is slow but beautiful)
  ggt <- ggtree::ggtree(clustered, layout = "daylight", branch.length = "none", MAX_COUNT = 1)

  # re-layout with TreeAndLeaf (converts to igraph object)
  # then convert to network for plotting with ggnetwork (better plotly compatability than ggtree)
  network_ggt <- intergraph::asNetwork(TreeAndLeaf::treeAndLeaf(ggt))

  # use the coordinates from TreeAndLeaf layout for the layout of the network
  coords <- data.frame(
    x = network::get.vertex.attribute(network_ggt, "coordX"),
    y = network::get.vertex.attribute(network_ggt, "coordY")
  )

  # transform network into simple df for plotting with ggplot
  data_for_plot <- ggnetwork::ggnetwork(network_ggt, layout = as.matrix(coords))

  if (enriched) {
    data_for_plot <- data_for_plot %>%
      left_join(starting_data, by = c("nodeAlias" = "cluster_lead"))
  } else {
    data_for_plot <- data_for_plot %>% left_join(starting_data, by = c("nodeAlias" = "cdr3_aa"))
  }

  data_for_plot <- data_for_plot %>%
    mutate(CDR3 = nodeAlias) # this column will be our tooltip so give it a useful name

  # table data doesn't need any of the network-specific stuff
  table_data <- data_for_plot %>%
    filter(isLeaf == TRUE) %>% # only leaves
    select(-c(
      x, y, coordX, coordY, isLeaf, nodeAlias, nodeColor, nodeFontSize, nodeLineColor,
      nodeLineWidth, nodeSize, vertex.names, xend, yend, edgeColor, edgeWidth, weight))

  # get full nt sequences for the table
  wanted_samples <- metadata %>%
        filter(panning_id == id) %>%
        filter(round == which_round) %>%
        pull(sample_num) %>%
        paste0("_")

  wanted_files <- str_subset(all_nucleotide_files, paste(wanted_samples, collapse = "|"))

  # to do: would be good to not have to read in the files every time we find a top 100 (just do one in the pre-render script i guess)
  nucleotide_sequences <- vroom(wanted_files)
  full_nt_seqs <- get_full_sequences(
    cdr3s = table_data$CDR3,
    nucleotide_sequences,
    trim_5p = 'CAGGTGCAGCTGCAG', trim_3p = 'GGTCACCGTCTCCTCA')

    table_data <- table_data %>%
        left_join(full_nt_seqs, by = c(CDR3 = "cdr3_aa"))

  # set the abundance and enrichment columns to use in the plot according to round
  if(enriched){
    abundance <- data_for_plot %>%
      select(starts_with(paste0("R", which_round))) %>%
      select(!contains("vs")) %>% # remove logfc
      mutate(abundance =
        purrr:::reduce(select(., everything()), pmax, na.rm = TRUE)) %>%
      pull(abundance)

    enrichment <- data_for_plot %>%
      select(starts_with(paste0("R", which_round))) %>%
      select(contains("vs")) %>% # only logfc
      mutate(enrichment =
        purrr:::reduce(select(., everything()), pmax, na.rm = TRUE)) %>%
      pull(enrichment)

      data_for_plot <- data_for_plot %>%
        mutate(abundance = abundance, enrichment = enrichment)# add these columns
  } else {
    data_for_plot <- data_for_plot %>%
        mutate(abundance = cdr3_cpm, enrichment = rep(NA, nrow(data_for_plot)))
  }

  # grab only necessary columns for plotting
  data_for_plot <- data_for_plot %>%
    select(x, y, coordX, coordY, isLeaf, CDR3, xend, yend, abundance, enrichment)

  # return the two dataframes
  return(list(
    tree_data = data_for_plot,
    table_data = table_data
  ))
}

plot_interactive_tree <- function (tree_data, table_data, name, enriched = FALSE) {

    table_data <- table_data %>%
      relocate(CDR3, .before = everything())

    # get just the leaves (equivalent to tips in phylogenetic trees)
    only_leaves <- filter(tree_data, isLeaf == TRUE)

    shared_only_leaves <- SharedData$new(only_leaves, key = ~CDR3, group = paste0(name, enriched))
    table_data_shared <- SharedData$new(table_data, key = ~CDR3, group = paste0(name, enriched))

    # make ggplot
    if (enriched){
      plot <- ggplot(
        shared_only_leaves, aes(x = x, y = y, xend = xend, yend = yend, label = CDR3)) +
        ggnetwork::geom_edges(data = tree_data, color = "grey") +
        geom_point(aes(size = log10(abundance), colour = enrichment)) +
        theme_void() +
        theme(legend.position = "bottom") +
        ggtitle(paste0("Most enriched sequences in ", name)) +
        scale_size(name = "Abundance: log10(CPM)") +
        scale_colour_gradient(name = "Enrichment: logFC", low = "#3b1a2a", high = "#e83e8c")

    } else {
      plot <- ggplot(
        shared_only_leaves, aes(x = x, y = y, xend = xend, yend = yend, label = CDR3)) +
        ggnetwork::geom_edges(data = tree_data, color = "grey") +
        geom_point(aes(size = log10(abundance)), colour = "#ff784fa4") +
        theme_void() +
        theme(legend.position = "bottom") +
        ggtitle(paste0("Most abundant sequences in ", name)) +
        scale_size(name = "Abundance: log10(CPM)")
    }

    # grab the legend to plot separately because plotly doesn't do legends well
    legend <- cowplot::ggdraw(cowplot::get_legend(plot))

    # with plotly we will plot a legend-less version of the plot
    plot_no_legend <- plot + theme(legend.position = "none")
    plotly_plot <- ggplotly(plot_no_legend, tooltip = "label") %>%
      plotly::layout(
      yaxis = list(showline = FALSE),
      xaxis = list(showline = FALSE)) %>%
      highlight( # interactivity
        on = "plotly_click",
        opacityDim = 0.55,
        color = "#ff00a2",
        selectize = FALSE) %>%
      style(hoverinfo = "none", traces = 1) # remove tooltip from internal nodes

    if (enriched){
      hide_these_cols <- list(
        list(targets = "_all", className = "dt-center"),
        list(targets = "cluster_members", visible = FALSE),
        list(targets = "full_nt_sequence", visible = FALSE),
        list(targets = "full_aa_sequence", visible = FALSE),
        list(targets = "trimmed_nt_sequence", visible = FALSE))
    } else {
      hide_these_cols <- list(
        list(targets = "_all", className = "dt-center"),
        list(targets = "full_nt_sequence", visible = FALSE),
        list(targets = "full_aa_sequence", visible = FALSE),
        list(targets = "sequence_alignment", visible = FALSE),
        list(targets = "sequence_alignment_aa", visible = FALSE),
        list(targets = "sample_id", visible = FALSE),
        list(targets = "library", visible = FALSE),
        list(targets = "antigen", visible = FALSE),
        list(targets = "round", visible = FALSE),
        list(targets = "replicate", visible = FALSE),
        list(targets = "replicate_id_informative", visible = FALSE),
        list(targets = "trimmed_nt_sequence", visible = FALSE))
    }
    table <- DT::datatable(table_data_shared, options = list(
      paging = TRUE,    ## paginate the output
      pageLength = 5,  ## number of rows to output for each page
      lengthMenu = c(10, 25, 50), # let people change it
      scrollX = TRUE,   ## enable scrolling on X axis
      autoWidth = TRUE, ## use smart column width handling
      dom = "Blfrtip",
      colReorder = TRUE,
      buttons = c("csv", "excel"),
      columnDefs = hide_these_cols),
      style = "bootstrap",
      rownames = FALSE,
      extensions = c("Buttons", "ColReorder")
      ) %>%
      formatRound(columns = which(sapply(table_data, is.numeric)), digits = 2)

    interactive_plot <- bscols(plotly_plot, table, widths = c(10, 12), device = "md")
    return(list(legend = legend, interactive_plot = interactive_plot))

}